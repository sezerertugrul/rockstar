from rockstar import RockStar

apl_code = "'Hello, world!'"
rock_it_bro = RockStar(days=400, file_name='helloworld.apl', code=apl_code)
rock_it_bro.make_me_a_rockstar()
