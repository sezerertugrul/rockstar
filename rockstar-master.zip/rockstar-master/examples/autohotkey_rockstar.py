from rockstar import RockStar

autohotkey_code = "Msgbox, Hello, world!"

rock_it_bro = RockStar(days=400, file_name='helloworld.ahk', code=autohotkey_code)
rock_it_bro.make_me_a_rockstar()
