from rockstar import RockStar

ags_code = 'Display("Hello, world!");'
rock_it_bro = RockStar(days=777, file_name='helloworld.asc', code=ags_code)
rock_it_bro.make_me_a_rockstar()
