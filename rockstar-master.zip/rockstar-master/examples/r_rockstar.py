from rockstar import RockStar

r_code = "cat ('Hello world!')"

rock_it_bro = RockStar(days=400, file_name='hello.r', code=r_code)
rock_it_bro.make_me_a_rockstar()
