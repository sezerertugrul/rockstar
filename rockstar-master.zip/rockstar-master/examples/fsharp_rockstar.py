from rockstar import RockStar

fsharp_code = 'printfn "Hello World!"'
rock_it_bro = RockStar(days=400, file_name='helloworld.fs', code=fsharp_code)
rock_it_bro.make_me_a_rockstar()
