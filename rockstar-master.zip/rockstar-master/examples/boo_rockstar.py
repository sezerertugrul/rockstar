from rockstar import RockStar

boo_code = 'print "Hello World!"'
rock_it_bro = RockStar(days=400, file_name='helloworld.boo', code=boo_code)
rock_it_bro.make_me_a_rockstar()
