from rockstar import RockStar

swift_code = """import Foundation

print('Hello World!')"""

rock_it_bro = RockStar(days=400, file_name='helloWorld.swift', code=swift_code)
rock_it_bro.make_me_a_rockstar()
