from rockstar import RockStar

algol_sixty_code = 'BEGIN DISPLAY("HELLO WORLD!") END.'
rock_it_bro = RockStar(days=400, file_name='helloworld.algol60', code=algol_sixty_code)
rock_it_bro.make_me_a_rockstar()
