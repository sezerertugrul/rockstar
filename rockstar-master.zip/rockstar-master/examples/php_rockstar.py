from rockstar import RockStar

php_code = "<?php echo 'hello world';"
rock_it_bro = RockStar(days=400, file_name='helloworld.php', code=php_code)
rock_it_bro.make_me_a_rockstar()
