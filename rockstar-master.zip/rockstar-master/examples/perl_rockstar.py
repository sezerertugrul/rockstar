from rockstar import RockStar

perl_code = 'print "Hello World"'
rock_it_bro = RockStar(days=400, file_name='hello_world.pl', code=perl_code)
rock_it_bro.make_me_a_rockstar()
