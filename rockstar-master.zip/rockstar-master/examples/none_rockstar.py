from rockstar import RockStar

# yup, there is a programming language called `none`
# https://bitbucket.org/duangle/none
# you better be a rockstar in none.

none_code = """(none
(print "Hello World")
)"""

rock_it_bro = RockStar(days=400, file_name='hello.n', code=none_code)
rock_it_bro.make_me_a_rockstar()
