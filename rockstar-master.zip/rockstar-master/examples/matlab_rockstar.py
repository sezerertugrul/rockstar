from rockstar import RockStar

matlab_code = 'disp("Hello World")'
rock_it_bro = RockStar(days=400, file_name='HelloWorld.m', code=matlab_code)
rock_it_bro.make_me_a_rockstar()
