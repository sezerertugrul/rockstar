from rockstar import RockStar

java_code = "System.out.println('Hello world')"
rock_it_bro = RockStar(days=400, file_name='hello.java', code=java_code)
rock_it_bro.make_me_a_rockstar()
