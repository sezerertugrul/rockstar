from rockstar import RockStar

scheme_code = '(display "Hello world")'
rock_it_bro = RockStar(days=400, file_name='helloWorld.scm', code=scheme_code)
rock_it_bro.make_me_a_rockstar()
