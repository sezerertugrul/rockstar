from rockstar import RockStar

markdown_code = '# Hello, world!'
rock_it_bro = RockStar(days=400, file_name='helloworld.md', code=markdown_code)
rock_it_bro.make_me_a_rockstar()
