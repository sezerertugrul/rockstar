from rockstar import RockStar

bash_code = "echo 'Hello, World!'"
rock_it_bro = RockStar(days=777, file_name='helloworld.sh', code=bash_code)
rock_it_bro.make_me_a_rockstar()
