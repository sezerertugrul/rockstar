from rockstar import RockStar

sql_code = "SELECT 'Hello World!';"
rock_it_bro = RockStar(days=400, file_name='hello_world.sql', code=sql_code)
rock_it_bro.make_me_a_rockstar()
