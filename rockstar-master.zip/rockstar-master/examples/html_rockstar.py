from rockstar import RockStar

html_code = "<h1>Hello World!</h1>"
rock_it_bro = RockStar(days=400, file_name='helloWorld.html', code=html_code)
rock_it_bro.make_me_a_rockstar()
