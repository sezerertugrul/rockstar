from rockstar import RockStar

facefuck_code = (":) :) :) :) :) :) :) :) :) :)\n=(\n:> :) :) :) :) :) :) :) :> :) :) :) :) :) :) :) :) :) :) :> :) :) :) :> :) :< :< :< :< :(\n"
		 "=)\n:> :) :) :P\n:> :) :P\n:) :) :) :) :) :) :) :P\n"
		 ":P\n:) :) :) :P\n:> :) :) :P\n:< :< :) :) :) :) :) :) :) :) :) :) :) :) :) :) :) :P\n:> :P\n:) :) :) :P\n:( :( :( :( :( :( :P\n"
		 ":( :( :( :( :( :( :( :( :P\n:> :) :P\n:> :P\n")
rock_it_bro = RockStar(days=400, file_name='helloWorld.ff', code=facefuck_code)
rock_it_bro.make_me_a_rockstar()
