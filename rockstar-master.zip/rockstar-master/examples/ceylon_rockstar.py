from rockstar import RockStar

ceylon_code = 'print("Hello world");'
rock_it_bro = RockStar(days=400, file_name='hello.ceylon', code=ceylon_code)
rock_it_bro.make_me_a_rockstar()
