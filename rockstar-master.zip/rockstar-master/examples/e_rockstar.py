from rockstar import RockStar

e_code = 'println("Hello, world!")'
rock_it_bro = RockStar(days=400, file_name='helloworld.E', code=e_code)
rock_it_bro.make_me_a_rockstar()
