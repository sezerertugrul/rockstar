from rockstar import RockStar

python_code = "print('Hello world')"
rock_it_bro = RockStar(days=400, file_name='helloWorld.py', code=python_code)
rock_it_bro.make_me_a_rockstar()
