from rockstar import RockStar

clisp_code = '(print "Hello, World!" )'
rock_it_bro = RockStar(days=400, file_name='helloWorld.cl', code=clisp_code)
rock_it_bro.make_me_a_rockstar()
