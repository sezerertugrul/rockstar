from rockstar import RockStar

ocaml_code = 'print_string "Hello world!\n";;'
rock_it_bro = RockStar(days=400, file_name='hello.ml', code=ocaml_code)
rock_it_bro.make_me_a_rockstar()
