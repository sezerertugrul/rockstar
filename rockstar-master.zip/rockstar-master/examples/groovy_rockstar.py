from rockstar import RockStar

groovy_code = "println 'Hello world'"
rock_it_bro = RockStar(days=400, file_name='helloWorld.groovy',
                       code=groovy_code)
rock_it_bro.make_me_a_rockstar()
