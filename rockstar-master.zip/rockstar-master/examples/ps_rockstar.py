from rockstar import RockStar

ps_code = "Write-Host 'Hello World!'"
rock_it_bro = RockStar(days=400, file_name='helloWorld.ps1', code=ps_code)
rock_it_bro.make_me_a_rockstar()
