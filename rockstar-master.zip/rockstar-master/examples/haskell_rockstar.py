from rockstar import RockStar

haskell_code = "main = putStrLn 'Hello, World!'"
rock_it_bro = RockStar(days=400, file_name='helloworld.hs', code=haskell_code)
rock_it_bro.make_me_a_rockstar()
