from rockstar import RockStar

awk_code = 'BEGIN { print "Hello, world!" }'
rock_it_bro = RockStar(days=400, file_name='helloworld.awk', code=awk_code)
rock_it_bro.make_me_a_rockstar()
