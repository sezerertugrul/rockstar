from rockstar import RockStar

nemerle_code = 'System.Console.WriteLine("Hello world")'
rock_it_bro = RockStar(days=400, file_name='hello.n', code=nemerle_code)
rock_it_bro.make_me_a_rockstar()
