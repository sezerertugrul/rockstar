from rockstar import RockStar

chapel_code = 'writeln("Hello, world!");'
rock_it_bro = RockStar(days=400, file_name='helloworld.chpl', code=chapel_code)
rock_it_bro.make_me_a_rockstar()
