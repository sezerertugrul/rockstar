from rockstar import RockStar

dart_code = "main() { print('Hello Word'); }"
rock_it_bro = RockStar(days=400, file_name='helloWorld.dart', code=dart_code)
rock_it_bro.make_me_a_rockstar()
