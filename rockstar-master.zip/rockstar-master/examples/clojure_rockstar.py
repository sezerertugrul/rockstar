from rockstar import RockStar

clojure_code = '(println "Hello world")'
rock_it_bro = RockStar(days=400, file_name='hello.clj', code=clojure_code)
rock_it_bro.make_me_a_rockstar()
